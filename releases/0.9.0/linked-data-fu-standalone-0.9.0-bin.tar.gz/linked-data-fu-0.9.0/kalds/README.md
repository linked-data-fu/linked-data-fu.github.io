Karlsruhe Linked Data Scenarios
===============================

In the following, we list scenarios for query answering over Linked Data with
Linked Programs.

== Hegel ==

Works authored by Georg Wilhelm Friedrich Hegel.

Data from multiple national libraries.

Query schema: Dublin Core.

== Redemption ==

Gross income of movies of actors that performed in The Shawshank Redemption.

Data from DBpedia and The Movie Database.

Query schema: LinkedMDB and DBpedia.

== Sargent ==

American Art Collective: things made by artists that influenced John Singer Sargent.

Data from DBpedia and American Arts Collective.

Query schema: Friend of a Friend and Dublin Core.

