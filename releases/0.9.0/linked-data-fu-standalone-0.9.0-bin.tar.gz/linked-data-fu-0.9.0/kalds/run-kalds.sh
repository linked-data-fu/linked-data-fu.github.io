#!/bin/sh

# script to run the Karlsruhe Linked Data Scenarios (KALDS)

ruleset=owl-ld

# programs
for file in `ls */*.n3 | grep -ve "-q"`; do
    dir=`dirname $file`
    OUTPUT=$dir/`basename $file .n3`
    echo "Program "$file" started with ruleset "$ruleset" on "`date`
    ../bin/ldfu.sh -v -p ../rulesets/$ruleset.n3 -p $file > $OUTPUT-$ruleset.nq 2> $OUTPUT-$ruleset-stderr.txt
    echo "Program "$file" to "$OUTPUT" finished on "`date`
done

# queries
for dir in `ls -d */`; do
    data=`ls $dir*.n3 | grep -ve -q.n3`
    data=`echo $data | sed -e "s/\.n3//"`-$ruleset.nq
    query=`ls $dir*.rq | grep -e -q.rq`
    OUTPUT=`dirname $query`/`basename $query .rq`
    echo "Query "$query" on "$data" started on "`date`
    ../bin/ldfu.sh -v -q $query $OUTPUT-$ruleset.tsv tsv -i $data ntriples 2> $OUTPUT-$ruleset-stderr.txt
    echo "Query "$query" to "$OUTPUT" finished on "`date`
done
