Linked Data-Fu
==============

Welcome to Linked Data-Fu!  You have come to the right place if you want to
access and process Linked Data quickly and easily.

Introduction
------------

Linked Data-Fu allows you to write programs that access and process Linked Data.
Following Linked Data principles, HTTP provides the basis for data access.
HTTP request and response messages are encoded in a graph-structured data format
called RDF (Resource Description Framework).

In contrast to programs written in imperative programming languages such as Java,
Python or JavaScript, programs in Linked Data-Fu are based on "if-then" rules.

A program specifies an initial state (consisting of requests and/or data).
The program may also specify the following state using rules:

* If a given pattern holds on the data, then assume that another pattern holds.
  We call rules that allow for derivation of new data deduction rules.
* If a given pattern holds on the data, then perform a HTTP request.
  We call rules that allow for specification of requests interaction rules.

Programs itself are written in a slight extension of RDF, in a syntax called
Notation3 (N3).

In short, Linked Data-Fu is an end-to-end data processing system that can be used
in data integration and system interoperation scenarios.

Running a Program
-----------------

Use

$ bin/ldfu.sh -p kalds/hegel/get-hegel.n3 > get-hegel.nt

to evaluate program get-hegel.n3; results are printed to standard output and redirected
to the file get-hegel.nt in N-Triples format.

Use

$ bin/ldfu.sh -p kalds/hegel/get-hegel.n3 -p rulesets/owl-ld.n3 > get-hegel.nt

to evaluate the program under OWL LD semantics.  Now, many more HTTP requests are
carried out, as program evaluation now takes into account owl:sameAs and other
constructs.

You may also specify SPARQL queries via the -q option:

-q kalds/hegel/hegel-q.rq result.xml xml

evaluates the SPARQL query 'kalds/hegel/hegel-q.rq' and outputs the results to the
file 'result.xml' in XML format.

We currently only support basic graph pattern queries, i.e., only simple WHERE clauses.

More Memory
-----------

Use

$ export JAVA_OPTS="-Xmx8G"
$ bin/ldfu.sh

to reserve 8G of heap memory to the Java Virtual Machine.

Proxy
-----

To specify a HTTP proxy, use the http_proxy environment variable.  The scripts in bin/
should grok http_proxy.
