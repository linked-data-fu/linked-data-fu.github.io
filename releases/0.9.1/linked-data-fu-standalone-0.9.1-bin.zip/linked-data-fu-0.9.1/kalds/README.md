Karlsruhe Linked Data Scenarios
===============================

In the following, we list scenarios for query answering over Linked Data with
Linked Programs.

== Community ==

Papers of co-authors of area chairs of ISWC 2007.

Data from DBLP and semanticweb.org.

Query schema: Semantic Web Research Community.

== Hegel ==

Works authored by Georg Wilhelm Friedrich Hegel.

Data from multiple national libraries.

Query schema: Dublin Core.

== Redemption ==

Movies of actors that performed in The Shawshank Redemption.

Data from DBpedia and The Movie Database.

Query schema: LinkedMDB. # and DBpedia.

== Sargent ==

American Art Collective: things made by artists that influenced John Singer Sargent.

Data from DBpedia and American Arts Collective.

Query schema: Friend of a Friend and Dublin Core.

