Linked Data-Fu
==============

Welcome to Linked Data-Fu!  You have come to the right place if you want to
access and process Linked Data quickly and easily.

Mailing List
------------
For discussion of Linked Data-Fu use the mailing list at <a href="https://groups.google.com/forum/#!forum/ldfu-discuss">Google Groups</a>.

Introduction
------------

Linked Data-Fu allows you to write programs that access and process Linked Data.
Following Linked Data principles, HTTP provides the basis for data access.
HTTP request and response messages are encoded in a graph-structured data format
called RDF (Resource Description Framework).

In contrast to programs written in imperative programming languages such as
Java, Python or JavaScript, programs in Linked Data-Fu are based on "if-then"
rules.

A program specifies an initial state (consisting of requests and/or data).
The program may also specify the following state using rules:

* If a given pattern holds on the data, then assume that another pattern holds.
  We call rules that allow for derivation of new data deduction rules.
* If a given pattern holds on the data, then perform a HTTP request.
  We call rules that allow for specification of requests interaction rules.

Programs itself are written in an extension of RDF, in a syntax called
Notation3 (N3).

In short, Linked Data-Fu is an end-to-end data processing system that can be
used in data integration and system interoperation scenarios.

Evaluating a Query
------------------

The basic functionality of Linked Data-Fu is that of a streaming query processor.

Use:

    $ bin/ldfu.sh -i examples/lubm-1.nt ntriples -q examples/lubm-q1.rq - tsv

to evaluate the SPARQL query 'examples/lubm-q1.rq' and print the results in TSV format
on stdout ('-').  The engine evaluates the query over the data 'examples/lubm-1.nt'.

Please note we support SPARQL queries with only a basic graph pattern in the WHERE
clause.

Evaluating a Deduction Rule Program
-----------------------------------

We can add specialised rulesets consisting of deduction rules to query evaluation.

Use:

    $ bin/ldfu.sh -r rulesets/rdfs.n3 -i examples/lubm-1.nt ntriples -q examples/lubm-q1.rq - tsv

to evaluate the query 'examples/lubm-q1.rq' over the data 'examples/lubm-1.nt', but
take a subset of the RDFS semantics into account.

Evaluating a Request Rule Program
---------------------------------

Linked Data-Fu also support the retrieval of Linked Data during runtime.  The next
program contains an atomic HTTP request, and request rules that specify which sources
should be dereferenced.

Use:

    $ bin/ldfu.sh -p examples/get-timbl-awards.n3 > examples/get-timbl-awards.nt

to evaluate program 'examples/get-timbl-awards.n3'; results (all inferences) are
printed to standard output and redirected to the file 'examples/get-timbl-awards.nt'
in N-Triples format.

Use:

    $ bin/ldfu.sh -p examples/get-timbl-awards.n3 -p rulesets/rdfs-plus.n3 > examples/get-timbl-awards.nt

to evaluate the program under RDFS Plus semantics.  Now, many more HTTP requests
are carried out, as program evaluation now takes into account owl:sameAs and
other constructs.

You may also specify SPARQL queries via the -q option:

    -q examples/timbl-awards.rq examples/timbl-awards.xml xml

evaluates the SPARQL query 'examples/timbl-awards.rq' and outputs the results to
the file 'examples/timbl-awards.xml' in XML format.

We currently only support basic graph pattern queries, i.e., only simple WHERE
clauses.

Instead of performing lookups during runtime, you can also evaluate queries on
local data.

Use:

    $ bin/ldfu.sh -q examples/timbl-awards.rq examples/timbl-awards.xml xml -i examples/get-timbl-awards.nt ntriples

to evaluate the SPARQL query against the local N-Triples file
'examples/get-timbl-awards.nt' in streaming fashion (i.e., the engine scans once
over the file and streams back answers to the query).

Memory Issues
-------------

Use:

    $ export JAVA_OPTS="-Xmx8G -Xms4G"
    $ bin/ldfu.sh

Or:

    $ JAVA_OPTS="-Xmx8G -Xms4G" ; bin/ldfu.sh

to reserve 8G of heap memory (start with 4G heap memory reserved) to the Java Virtual
Machine.  Linked Data-Fu relies on main memory a lot, so the more memory you give to
the JVM, the better.

If you do not use rules, the "-d" option lowers memory consumption considerably.

Proxy
-----

To specify a HTTP proxy, use the http_proxy environment variable.  The scripts
in bin/ should grok http_proxy.  Assuming there is a local proxy available, use:

    $ export http_proxy="http://localhost:3128/"