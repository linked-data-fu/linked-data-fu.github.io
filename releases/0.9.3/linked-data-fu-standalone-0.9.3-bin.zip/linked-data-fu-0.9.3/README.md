Linked Data-Fu
==============

Introduction
------------

Linked Data-Fu allows you to write programs that access and process Linked Data
based on "if-then" rules.

Linked Data-Fu is a dataflow system that processes streams of triples as input
and outputs streams of triples (via SPARQL CONSTRUCT queries) or streams of
solutions (via SPARQL SELECT queries).

A program specifies an initial state consisting of input streams.  The program may
also specify the following state using rules:

* Deduction rules: if a given pattern holds on the data, then assume that another
  pattern holds.
* Request rules: if a given pattern holds on the data, then perform a HTTP request.

Programs itself are written in an extension of RDF, in a syntax called
Notation3 (N3).

Linked Data-Fu is an end-to-end data processing system that can be used in data
integration and system interoperation scenarios.

The following will introduce the functionality of Linked Data-Fu.

Parsing a File
--------------

Use:

    $ bin/ldfu.sh -i examples/lubm-1.nt > output.nt

to parse the N-Triples file 'examples/lubm-1.nt' while streaming the resulting
triples to standard output (stdout).  '> out' redirects stdout to a file 'output.nt'.

Supported formats for input streams are:
* rdfxml (.rdf)
* ntriples (.nt)
* nquads (.nq)
* turtle (.ttl)

Supported formats for triple output streams are:
* rdfxml (.rdf)
* ntriples (.nt)
* nquads (.nq)

You can specify multiple files via the '-i' option.  The files are muliplexed into a
single stream.

Evaluating a Query
------------------

On the stream you can register queries specified in SPARQL syntax.  Given the complexities
around combining queries and rules (see next paragraph), Linked Data-Fu just supports queries
with a single basic graph pattern in the WHERE clause.

CONSTRUCT queries return a stream of triples.
SELECT queries return a stream of tuples (SPARQL solutions).

Use:

    $ bin/ldfu.sh -i examples/lubm-1.nt -q examples/lubm-q1.rq lubm-q.tsv

to evaluate the query 'examples/lubm-q1.rq' and print the results in TSV format to
lubm-q.tsv.

Supported formats for SPARQL solution output streams are:
* xml (.srx)
* html (.html)
* tsv (.tsv)

Evaluating a Deduction Rule Program
-----------------------------------

You can add specialised rulesets consisting of deduction rules to query evaluation.

Use:

    $ bin/ldfu.sh -r rulesets/rdfs.n3 -i examples/lubm-1.nt ntriples -q examples/lubm-q1.rq - tsv

to evaluate the query 'examples/lubm-q1.rq' over the data 'examples/lubm-1.nt', but
take a subset of the RDFS semantics into account.

Evaluating a Request Rule Program
---------------------------------

Linked Data-Fu also supports the retrieval of Linked Data during runtime.  The next
program contains an atomic HTTP request, and request rules that specify which sources
should be dereferenced.

Use:

    $ bin/ldfu.sh -p examples/get-timbl-awards.n3 > examples/get-timbl-awards.nt

to evaluate program 'examples/get-timbl-awards.n3' consisting of an atomic HTTP GET
request and a request rule specifying which links to follow.  The results of program
evaluation are printed to standard output and redirected to the file
'examples/get-timbl-awards.nt'.

Use:

    $ bin/ldfu.sh -p examples/get-timbl-awards.n3 -p rulesets/rdfs-plus.n3 > examples/get-timbl-awards.nt

to evaluate the program under RDFS Plus semantics.  Now, many more HTTP requests
are carried out, as program evaluation takes into account owl:sameAs and other
constructs.

You may also specify SPARQL queries via the -q option:

    -q examples/timbl-awards.rq examples/timbl-awards.srx xml

evaluates the SPARQL query 'examples/timbl-awards.rq' and outputs the results to
the file 'examples/timbl-awards.srx' in XML format.  The input data is either specified via
the "-i" option or via HTTP requests as part of a program.

Memory Issues
-------------

Use:

    $ export JAVA_OPTS="-Xmx8G -Xms4G"
    $ bin/ldfu.sh

Or:

    $ JAVA_OPTS="-Xmx8G -Xms4G" bin/ldfu.sh

to reserve 8G of heap memory (start with 4G heap memory reserved) to the Java Virtual
Machine.  Linked Data-Fu relies on main memory a lot: the more memory you give to
the JVM, the better.

Proxy
-----

To specify a HTTP proxy, use the http_proxy environment variable.  The scripts
in bin/ should grok http_proxy.  Assuming there is a local proxy available, use:

    $ export http_proxy="http://localhost:3128/"

Mailing List
------------

For discussion of Linked Data-Fu use the mailing list at <a href="https://groups.google.com/forum/#!forum/ldfu-discuss">Google Groups</a>.
Subscribe via email to ldfu-discuss+subscribe@googlegroups.com.